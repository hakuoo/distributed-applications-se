﻿namespace WebApplication2.Dtos;

public class CredentialRequestDto
{
    public string Username { get; set; }
    public string Password { get; set; }
}