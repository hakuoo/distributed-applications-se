﻿namespace WebApplication2.Dtos;

public class CredentialResponseDto
{
    public string Token { get; set; }
}