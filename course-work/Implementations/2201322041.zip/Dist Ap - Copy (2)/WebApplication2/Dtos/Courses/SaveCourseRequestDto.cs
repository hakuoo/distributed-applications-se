﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using WebApplication2.Model;

namespace WebApplication2.Dtos.Courses;

public class SaveCourseRequestDto
{
    [Required] [StringLength(100)] public string CourseName { get; set; }

    [StringLength(500)] public string CourseDescription { get; set; }
    public int? DepartmentID { get; set; }

    [Required] public int Credits { get; set; }
    
    public DateTime? StartDate { get; set; }

    public DateTime? EndDate { get; set; }
}