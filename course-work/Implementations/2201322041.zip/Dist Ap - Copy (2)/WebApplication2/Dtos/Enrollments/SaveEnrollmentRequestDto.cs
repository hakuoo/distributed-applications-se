﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Dtos.Enrollments;

public class SaveEnrollmentRequestDto
{
    public int? StudentID { get; set; }
    
    public int? CourseID { get; set; }
    
    [Required] public DateTime EnrollmentDate { get; set; }

    [StringLength(2)] public string Grade { get; set; }
}