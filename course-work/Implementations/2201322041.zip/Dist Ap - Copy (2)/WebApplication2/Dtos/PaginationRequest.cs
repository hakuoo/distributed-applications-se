﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Dtos;

public class PaginationRequest
{
    [FromQuery]public int? CurrentPage { get; set; }
    [FromQuery][Range(1, 20)]public int? ResultPerPage { get; set; }
}