﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Dtos.Students;

public class SaveStudentRequestDto
{
    [Required] [StringLength(50)] public string FirstName { get; set; }

    [Required] [StringLength(50)] public string LastName { get; set; }

    public DateTime? DateOfBirth { get; set; }

    [Range(0, 4.0)] public decimal? GPA { get; set; }

    public DateTime? EnrollmentDate { get; set; }

    [StringLength(100)] public string Major { get; set; }
}