﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Dtos.Departments;

public class SaveDepartmentRequestDto
{
    [Required] [StringLength(100)] public string DepartmentName { get; set; }

    [StringLength(100)] public string DepartmentHead { get; set; }

    [StringLength(50)] public string BuildingName { get; set; }

    [StringLength(20)] public string DepartmentPhone { get; set; }

    [StringLength(100)] public string DepartmentEmail { get; set; }
}