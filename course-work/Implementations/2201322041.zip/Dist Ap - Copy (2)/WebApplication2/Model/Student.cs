﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Model
{
    public class Student
    {
        [Key] public int StudentID { get; set; }

        [Required] [StringLength(50)] public string FirstName { get; set; }

        [Required] [StringLength(50)] public string LastName { get; set; }

        [DataType(DataType.Date)] public DateTime? DateOfBirth { get; set; }

        [Range(0, 4.0)] public decimal? GPA { get; set; }

        [DataType(DataType.DateTime)] public DateTime? EnrollmentDate { get; set; }

        [StringLength(100)] public string Major { get; set; }
        public virtual ICollection<Enrollment> Enrollments { get; set; }

    }
}