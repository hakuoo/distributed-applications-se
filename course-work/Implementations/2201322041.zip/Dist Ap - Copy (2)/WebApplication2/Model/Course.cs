﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication2.Model
{
    public class Course
    {
        [Key] [DatabaseGenerated(DatabaseGeneratedOption.Identity)] public int CourseID { get; set; }

        [Required] [StringLength(100)] public string CourseName { get; set; }

        [StringLength(500)] public string CourseDescription { get; set; }   

        [Required] public int Credits { get; set; }
        public int? DepartmentID { get; set; }
        [ForeignKey("DepartmentID")] public virtual Department Department { get; set; }

        [DataType(DataType.Date)] public DateTime? StartDate { get; set; }

        [DataType(DataType.Date)] public DateTime? EndDate { get; set; }
        
        public virtual ICollection<Enrollment> Enrollments { get; set; }
    }
}