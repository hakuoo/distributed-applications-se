﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Model
{
    public class Department
    {
        [Key] public int DepartmentID { get; set; }

        [Required] [StringLength(100)] public string DepartmentName { get; set; }

        [StringLength(100)] public string DepartmentHead { get; set; }

        [StringLength(50)] public string BuildingName { get; set; }

        [StringLength(20)] public string DepartmentPhone { get; set; }

        [StringLength(100)] public string DepartmentEmail { get; set; }
        public virtual ICollection<Course> Courses { get; set; }
    }
}