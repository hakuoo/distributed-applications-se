﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using WebApplication2.Configuration;
using WebApplication2.Dtos;

namespace WebApplication2.Controllers;

[Route("api/[controller]")]
[ApiController]
[AllowAnonymous]
public class TokenController(
    IOptions<JwtSettingsConfiguration> jwtOptions,
    IOptions<CredentialsConfiguration> credentialOptions) : ControllerBase
{
    private readonly SymmetricSecurityKey _securityKey = new(Encoding.UTF8.GetBytes(jwtOptions.Value.Secret));

    [HttpPost]
    [Route("generate")]
    public ActionResult<CredentialResponseDto> GenerateToken([FromBody] CredentialRequestDto credentials)
    {
        if (credentials.Username != credentialOptions.Value.Username ||
            credentials.Password != credentialOptions.Value.Password)
        {
            return Unauthorized();
        }

        var claims = new[]
        {
            new Claim(ClaimTypes.Name, credentials.Username)
        };

        var token = new JwtSecurityToken(
            issuer: jwtOptions.Value.Issuer,
            audience: jwtOptions.Value.Audience,
            claims: claims,
            expires: DateTime.UtcNow.AddHours(1),
            signingCredentials: new SigningCredentials(_securityKey, SecurityAlgorithms.HmacSha256)
        );

        return Ok(new CredentialResponseDto()
        {
            Token = new JwtSecurityTokenHandler().WriteToken(token)
        });
    }
}