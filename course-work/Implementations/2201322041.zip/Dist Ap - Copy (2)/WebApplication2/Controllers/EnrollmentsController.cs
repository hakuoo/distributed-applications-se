﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Deltas;
using Microsoft.AspNetCore.OData.Formatter;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Dtos;
using WebApplication2.Dtos.Enrollments;
using WebApplication2.Model;
using WebApplication2.Repositories.DbContext;

namespace WebApplication2.Controllers
{
    [Route("odata/[controller]")]
    [Authorize]
    public class EnrollmentsController(ProjectDbContext context) : ODataController
    {
        // GET: odata/Enrollments
        [EnableQuery]
        [HttpGet]
        public IQueryable<Enrollment> GetEnrollments(PaginationRequest paginationRequest)
        {
            var query =  context.Enrollments.AsQueryable();

            if (paginationRequest is { ResultPerPage: not null, CurrentPage: > 0 })
            {
                query = query
                    .Skip(paginationRequest.ResultPerPage.Value * (paginationRequest.CurrentPage.Value - 1))
                    .Take(paginationRequest.ResultPerPage.Value);
            }

            return query;
        }

        // GET: odata/Enrollments/enrollment(5)
        [EnableQuery]
        [HttpGet("enrollment")]
        public SingleResult<Enrollment> GetEnrollment([FromODataUri] int key)
        {
            return SingleResult.Create(context.Enrollments.Where(enrollment => enrollment.EnrollmentID == key));
        }

        // PUT: odata/Enrollments(5)
        [HttpPut]
        public async Task<IActionResult> PutEnrollment([FromODataUri] int key, [FromBody] SaveEnrollmentRequestDto req)
        {
            var enrollment = await context.Enrollments.FirstOrDefaultAsync(x => x.EnrollmentID == key);
            if (enrollment == null)
            {
                return NotFound();
            }

            enrollment.StudentID = req.StudentID;
            enrollment.CourseID = req.CourseID;
            enrollment.EnrollmentDate = req.EnrollmentDate;
            enrollment.Grade = req.Grade;
            
            await context.SaveChangesAsync();

            return Updated(enrollment);
        }

        // POST: odata/Enrollments
        [HttpPost]
        public async Task<IActionResult> PostEnrollment([FromBody] SaveEnrollmentRequestDto req)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var enrollment = new Enrollment()
            {
                Grade = req.Grade,
                EnrollmentDate = req.EnrollmentDate,
                CourseID = req.CourseID,
                StudentID = req.StudentID,
            };
            
            var entry = context.Enrollments.Add(enrollment);
            await context.SaveChangesAsync();

            return Ok(entry.Entity);
        }

        // DELETE: odata/Enrollments(5)
        [HttpDelete]
        public async Task<IActionResult> DeleteEnrollment([FromODataUri] int key)
        {
            var enrollment = await context.Enrollments.FindAsync(key);
            if (enrollment == null)
            {
                return NotFound();
            }

            context.Enrollments.Remove(enrollment);
            await context.SaveChangesAsync();

            return NoContent();
        }
        
        [HttpGet("search")]
        public IActionResult SearchEnrollments(int? studentId, int? courseId)
        {
            var enrollments = context.Enrollments
                .Where(e => (studentId == null || e.StudentID == studentId)
                            && (courseId == null || e.CourseID == courseId))
                .ToList();

            return Ok(enrollments);
        }
    }
}