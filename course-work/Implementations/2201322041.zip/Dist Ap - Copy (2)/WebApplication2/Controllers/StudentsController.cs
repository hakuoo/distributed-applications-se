﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Deltas;
using Microsoft.AspNetCore.OData.Formatter;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using WebApplication2.Dtos;
using WebApplication2.Dtos.Students;
using WebApplication2.Model;
using WebApplication2.Repositories.DbContext;

namespace WebApplication2.Controllers
{
    [Route("odata/[controller]")]
    [Authorize]
    public class StudentsController(ProjectDbContext context) : ODataController
    {
        // GET: odata/Students
        [EnableQuery]
        [HttpGet]
        public IQueryable<Student> GetStudents(PaginationRequest paginationRequest)
        {
            var query =  context.Students.AsQueryable();

            if (paginationRequest is { ResultPerPage: not null, CurrentPage: > 0 })
            {
                query = query
                    .Skip(paginationRequest.ResultPerPage.Value * (paginationRequest.CurrentPage.Value - 1))
                    .Take(paginationRequest.ResultPerPage.Value);
            }

            return query;
        }

        // GET: odata/Students/student(5)
        [EnableQuery]
        [HttpGet("student")]
        public SingleResult<Student> GetStudent([FromODataUri] int key)
        {
            return SingleResult.Create(context.Students.Where(student => student.StudentID == key));
        }

        // PUT: odata/Students(5)
        [HttpPut]
        public async Task<IActionResult> PutStudent([FromODataUri] int key, [FromBody] SaveStudentRequestDto req)
        {
            var student = await context.Students.FindAsync(key);
            if (student == null)
            {
                return NotFound();
            }

            student.FirstName = req.FirstName;
            student.LastName = req.LastName;
            student.EnrollmentDate = req.EnrollmentDate;
            student.Major = req.Major;
            student.DateOfBirth = req.DateOfBirth;
            student.GPA = req.GPA;

            await context.SaveChangesAsync();

            return Updated(student);
        }

        // POST: odata/Students
        [HttpPost]
        public async Task<IActionResult> PostStudent([FromBody] SaveStudentRequestDto req)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var student = new Student()
            {
                EnrollmentDate = req.EnrollmentDate,
                Major = req.Major,
                FirstName = req.FirstName,
                LastName = req.LastName,
                DateOfBirth = req.DateOfBirth,
                GPA = req.GPA,
            };

            var entry = context.Students.Add(student);
            await context.SaveChangesAsync();

            return Ok(entry.Entity);
        }

        // DELETE: odata/Students(5)
        [HttpDelete]
        public async Task<IActionResult> DeleteStudent([FromODataUri] int key)
        {
            var student = await context.Students.FindAsync(key);
            if (student == null)
            {
                return NotFound();
            }

            context.Students.Remove(student);
            await context.SaveChangesAsync();

            return NoContent();
        }

        [HttpGet("search")]
        public IActionResult SearchStudents(string firstName, string lastName)
        {
            var students = context.Students
                .Where(s => (string.IsNullOrEmpty(firstName) || s.FirstName.Contains(firstName))
                            && (string.IsNullOrEmpty(lastName) || s.LastName.Contains(lastName)))
                .ToList();

            return Ok(students);
        }
    }
}