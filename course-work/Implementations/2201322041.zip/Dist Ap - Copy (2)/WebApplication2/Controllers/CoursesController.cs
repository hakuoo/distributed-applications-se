﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Deltas;
using Microsoft.AspNetCore.OData.Formatter;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using WebApplication2.Dtos;
using WebApplication2.Dtos.Courses;
using WebApplication2.Model;
using WebApplication2.Repositories.DbContext;

namespace WebApplication2.Controllers
{
    [Route("odata/[controller]")]
    [Authorize]
    public class CoursesController(ProjectDbContext context) : ODataController
    {
        // GET: odata/Courses
        [EnableQuery]
        [HttpGet]
        public IQueryable<Course> GetCourses(PaginationRequest paginationRequest)
        {
            var query =  context.Courses.AsQueryable();

            if (paginationRequest is { ResultPerPage: not null, CurrentPage: > 0 })
            {
                query = query
                    .Skip(paginationRequest.ResultPerPage.Value * (paginationRequest.CurrentPage.Value - 1))
                    .Take(paginationRequest.ResultPerPage.Value);
            }

            return query;
        }

        // GET: odata/Courses/course(5)
        [EnableQuery]
        [HttpGet("course")]
        public SingleResult<Course> GetCourse([FromODataUri] int key)
        {
            return SingleResult.Create(context.Courses.Where(department => department.CourseID == key));
        }

        // PUT: odata/Courses(5)
        [HttpPut]
        public async Task<IActionResult> PutCourse([FromODataUri] int key, [FromBody] SaveCourseRequestDto req)
        {
            var course = await context.Courses.FindAsync(key);
            if (course == null)
            {
                return NotFound();
            }

            course.CourseName = req.CourseName;
            course.CourseDescription = req.CourseDescription;
            course.DepartmentID = req.DepartmentID;
            course.Credits = req.Credits;
            course.StartDate = req.StartDate;
            course.EndDate = req.EndDate;
            
            await context.SaveChangesAsync();

            return Updated(course);
        }

        // POST: odata/Courses
        [HttpPost]
        public async Task<IActionResult> PostCourse([FromBody] SaveCourseRequestDto req)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var course = new Course();
            
            course.CourseName = req.CourseName;
            course.CourseDescription = req.CourseDescription;
            course.DepartmentID = req.DepartmentID;
            course.Credits = req.Credits;
            course.StartDate = req.StartDate;
            course.EndDate = req.EndDate;

            var entity = context.Courses.Add(course);
            await context.SaveChangesAsync();

            return Ok(entity.Entity);
        }

        // DELETE: odata/Courses(5)
        [HttpDelete]
        public async Task<IActionResult> DeleteCourse([FromODataUri] int key)
        {
            var course = await context.Courses.FindAsync(key);
            if (course == null)
            {
                return NotFound();
            }

            context.Courses.Remove(course);
            await context.SaveChangesAsync();

            return NoContent();
        }

        [HttpGet("search")]
        public IActionResult SearchCourses(string courseName)
        {
            var courses = context.Courses
                .Where(c => string.IsNullOrEmpty(courseName) || c.CourseName.Contains(courseName))
                .ToList();

            return Ok(courses);
        }
    }
}