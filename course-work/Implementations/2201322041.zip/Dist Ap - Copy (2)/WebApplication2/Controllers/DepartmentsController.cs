﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Deltas;
using Microsoft.AspNetCore.OData.Formatter;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using WebApplication2.Dtos;
using WebApplication2.Dtos.Departments;
using WebApplication2.Model;
using WebApplication2.Repositories.DbContext;

namespace WebApplication2.Controllers
{
    [Route("odata/[controller]")]
    [Authorize]
    public class DepartmentsController(ProjectDbContext context) : ODataController
    {
        // GET: odata/Departments
        [EnableQuery]
        [HttpGet]
        public IQueryable<Department> GetDepartments(PaginationRequest paginationRequest)
        {
            var query =  context.Departments.AsQueryable();

            if (paginationRequest is { ResultPerPage: not null, CurrentPage: > 0 })
            {
                query = query
                    .Skip(paginationRequest.ResultPerPage.Value * (paginationRequest.CurrentPage.Value - 1))
                    .Take(paginationRequest.ResultPerPage.Value);
            }

            return query;
        }

        // GET: odata/Departments/department(5)
        [EnableQuery]
        [HttpGet("department")]
        public SingleResult<Department> GetDepartment([FromODataUri] int key)
        {
            return SingleResult.Create(context.Departments.Where(department => department.DepartmentID == key));
        }

        // PUT: odata/Departments(5)
        [HttpPut]
        public async Task<IActionResult> PutDepartment([FromODataUri] int key, [FromBody] SaveDepartmentRequestDto req)
        {
            var department = await context.Departments.FindAsync(key);
            if (department == null)
            {
                return NotFound();
            }

            department.DepartmentName = req.DepartmentName;
            department.DepartmentEmail = req.DepartmentEmail;
            department.DepartmentHead = req.DepartmentHead;
            department.DepartmentPhone = req.DepartmentPhone;
            department.BuildingName = req.BuildingName;
            
            
            await context.SaveChangesAsync();

            return Updated(department);
        }

        // POST: odata/Departments
        [HttpPost]
        public async Task<IActionResult> PostDepartment([FromBody] SaveDepartmentRequestDto req)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var department = new Department()
            {
                DepartmentPhone = req.DepartmentPhone,
                DepartmentName = req.DepartmentName,
                BuildingName = req.BuildingName,
                DepartmentEmail = req.DepartmentEmail,
                DepartmentHead = req.DepartmentHead,
            };
            
            var entry  =context.Departments.Add(department);
            await context.SaveChangesAsync();

            return Ok(entry.Entity);
        }

        // DELETE: odata/Departments(5)
        [HttpDelete]
        public async Task<IActionResult> DeleteDepartment([FromODataUri] int key)
        {
            var department = await context.Departments.FindAsync(key);
            if (department == null)
            {
                return NotFound();
            }

            context.Departments.Remove(department);
            await context.SaveChangesAsync();

            return NoContent();
        }
        
        [HttpGet("search")]
        public IActionResult SearchDepartments(string departmentName)
        {
            var departments = context.Departments
                .Where(d => string.IsNullOrEmpty(departmentName) || d.DepartmentName.Contains(departmentName))
                .ToList();

            return Ok(departments);
        }
    }
}