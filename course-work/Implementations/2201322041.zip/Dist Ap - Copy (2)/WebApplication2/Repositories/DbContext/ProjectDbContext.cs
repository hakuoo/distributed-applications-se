﻿using Microsoft.EntityFrameworkCore;
using WebApplication2.Model;

namespace WebApplication2.Repositories.DbContext;

public class ProjectDbContext(DbContextOptions<ProjectDbContext> options)
    : Microsoft.EntityFrameworkCore.DbContext(options)
{
    public DbSet<Student> Students { get; set; }
    public DbSet<Course> Courses { get; set; }
    public DbSet<Department> Departments { get; set; }
    public DbSet<Enrollment> Enrollments { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Enrollment>()
            .HasKey(e => new { e.StudentID, e.CourseID });

        modelBuilder.Entity<Enrollment>()
            .HasOne(e => e.Student)
            .WithMany(s => s.Enrollments)
            .HasForeignKey(e => e.StudentID)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Enrollment>()
            .HasOne(e => e.Course)
            .WithMany(c => c.Enrollments)
            .HasForeignKey(e => e.CourseID)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Course>()
            .HasMany(c => c.Enrollments)
            .WithOne(e => e.Course)
            .HasForeignKey(e => e.CourseID)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Department>()
            .HasMany(d => d.Courses)
            .WithOne(c => c.Department)
            .HasForeignKey(c => c.DepartmentID)
            .OnDelete(DeleteBehavior.Cascade);
        
        modelBuilder.Entity<Student>()
            .Property(s => s.FirstName)
            .IsRequired();

        modelBuilder.Entity<Student>()
            .Property(s => s.LastName)
            .IsRequired();

        modelBuilder.Entity<Course>()
            .Property(c => c.CourseName)
            .IsRequired();

        modelBuilder.Entity<Course>()
            .Property(c => c.Credits)
            .IsRequired();

        modelBuilder.Entity<Department>()
            .Property(d => d.DepartmentName)
            .IsRequired();
    }}